import { Component, OnInit } from '@angular/core';

import { IProduct } from './product';
import { ProductService } from './product.service';

@Component({
    moduleId:module.id,
    selector: 'pm-products',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
    pageTitle: string = 'Product List';
    imageWidth: number = 50;
    imageMargin: number = 2;
    showImage: boolean = false;

    _listFilter: string;
    get listFilter(): string {
        return this._listFilter;
    }

   set listFilter(value: string) {
        this._listFilter = value;
        console.log(this.listFilter);
        this.filteredProducts = 
			this.listFilter ? this.performFilter(this.listFilter) 
                : this.products;
        console.log("filteredProducts: "+this.filteredProducts[0]);
    }

    filteredProducts: IProduct[];

	performFilter(filterBy: string): IProduct[] {
        console.log("peform filter: "+filterBy);
        filterBy = filterBy.toLocaleLowerCase();
        let temp: IProduct[] = this.products.filter((product: IProduct) =>
            product.productName.toLocaleLowerCase().indexOf(filterBy)
                !== -1);
                
        console.log(temp);
        return temp;
    }

    
    products: IProduct[] = [
        {
            "productId": 2,
            "productName": "Garden Cart",
            "productCode": "GDN-0023",
            "releaseDate": "March 18, 2016",
            "description": "15 gallon capacity rolling garden cart",
            "price": 32.99,
            "starRating": 4.2,
            "imageUrl": "http://openclipart.org/image/300px/svg_to_png/58471/garden_cart.png"
        },
        {
            "productId": 5,
            "productName": "Hammer",
            "productCode": "TBX-0048",
            "releaseDate": "May 21, 2016",
            "description": "Curved claw steel hammer",
            "price": 8.9,
            "starRating": 4.8,
            "imageUrl": "http://openclipart.org/image/300px/svg_to_png/73/rejon_Hammer.png"
        }
    ];

    /*constructor() {
        this.filteredProducts = this.products;
        this.listFilter = 'cart';
    }*/

   

    toggleImage(): void {
        this.showImage = !this.showImage;
    }

    constructor(private _productService: ProductService){
    }  

    errorMessage: string;
    ngOnInit(): void {
        console.log('In OnInit');
        //this.products = this._productService.getProducts();

        this._productService.getProducts().subscribe(
            products => {
                this.products = products;
                this.filteredProducts=products;
            },
            error => this.errorMessage = <any>error
        );

        this.filteredProducts = this.products;
    }
}
