package CG.JsonToJavaObject;

import java.io.File;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ){
    try{
		File file=new File("d:\\Associate.json");
		Serializable.doSerializable(file);
		Serializable.doDeDerialization();
}
	catch(Exception e){
		e.printStackTrace();
	}
    
}
}
