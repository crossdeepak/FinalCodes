
public class MaxNo {

	public static void main(String[] args) {
		int i,n=5;
		int [] numlist = {1,4,5,2,8};
		for(i=0;i<n;i++){
			if (a[i]>max)
				max=a[i];
		}
	}
}
