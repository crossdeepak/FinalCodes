package com.cg.project.main;

import com.cg.project.services.MathServices;
import com.cg.project.services.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		MathServices mathServices = new MathServicesImpl();
		System.out.println(mathServices.Add(100, 200));
	}

}
