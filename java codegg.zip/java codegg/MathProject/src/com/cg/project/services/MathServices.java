package com.cg.project.services;

public interface MathServices {
	public abstract int Add(int n1,int n2);
	abstract int Sub(int n1,int n2);
	int Div(int n1,int n2);
}
