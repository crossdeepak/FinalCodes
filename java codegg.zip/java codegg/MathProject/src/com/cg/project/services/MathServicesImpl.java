package com.cg.project.services;

public class MathServicesImpl implements MathServices {

	@Override
	public int Add(int n1, int n2) {
		
		return n1+n2;
	}

	@Override
	public int Sub(int n1, int n2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int Div(int n1, int n2) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
