
public class MainClass {

	public static void main(String[] args) {
		int num=200;
		Integer iob=num;
		Integer iob2=500;
		System.out.println(iob);
		int num2=iob2;
		System.out.println(num2);
	} 

	}

