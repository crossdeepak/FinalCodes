package com.cg.StaticVar.main;

public class MainClass {

	public static void main(String[] args) {
		

	}

}
