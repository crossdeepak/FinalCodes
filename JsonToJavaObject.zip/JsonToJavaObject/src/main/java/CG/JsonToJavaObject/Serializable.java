package CG.JsonToJavaObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Serializable {
	public static void doSerializable(File file) throws FileNotFoundException, IOException{
		Associate associate=new Associate(1234, 20000, "Deepak", "Muraree");
		ObjectMapper mapper=new ObjectMapper();
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
		try{
			String json=mapper.writeValueAsString(associate);
			System.out.println(json);
			String prettyJson=mapper.writerWithDefaultPrettyPrinter().writeValueAsString(associate);
			System.out.println(prettyJson);
			dest.writeObject(prettyJson);
		}
       catch (JsonGenerationException e) {
         e.printStackTrace();
     } catch (JsonMappingException e) {
         e.printStackTrace();
     } catch (IOException e) {
         e.printStackTrace();
     }
		}
	}
	public static void doDeDerialization() throws FileNotFoundException, IOException, ClassNotFoundException{
			JSONParser parser = new JSONParser();
			 
	        try {
	 
	            Object obj = parser.parse(new FileReader(
	                    "d:\\Associate2.json"));
	 
	            JSONObject jsonObject = (JSONObject) obj;
	 
	            Long associateId = (Long) jsonObject.get("associateId");
	            Long basicSalary = (Long) jsonObject.get("basicSalary");
	            String firstName = (String) jsonObject.get("firstName");
	            String lastName = (String) jsonObject.get("lastName");
	 
	            System.out.println("Id: " + associateId);
	            System.out.println("BasicSalary: " + basicSalary);
	            System.out.println("FirstName:" + firstName);
	                System.out.println("LastName:" + lastName);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
			}
			
	}
